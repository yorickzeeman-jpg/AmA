import { useState, useRef, useCallback } from 'react'
import { T, genRef, calcSlaDate, allocateCase } from '../data.js'
import { Icon, Btn, Field, inputSt, selectSt, StatusBadge } from '../ui.jsx'

// ═════════════════════════════════════════════════════════════════════════════
// FUNERAL PORTAL PDF EXTRACTION ENGINE  v2
//
// The fundamental problem with v1: it assumed "Label: Value" colon-separated
// format. Funeral Portal PDFs (and many HTML-to-PDF exports) produce text where
// labels and values are on consecutive lines with NO colon:
//
//   Reference\nAMCU-20260609-62605\nMember Name\nMphahlele\n...
//
// The v2 engine uses three strategies in priority order:
//   1. LABEL:VALUE  — "Reference: AMCU-123"  (email / some PDFs)
//   2. LABEL\nVALUE — label on line N, value on line N+1 (Funeral Portal PDF)
//   3. INLINE       — standalone patterns (13-digit IDs, phone numbers, emails)
//
// Each extracted field records HOW it was found (source) and a confidence
// score (0–100) — used by the Extraction Debug Panel.
// ═════════════════════════════════════════════════════════════════════════════

// ── Funeral Portal field label map ───────────────────────────────────────────
// Maps canonical field keys to the label variations that may appear in PDFs.
// Order matters — more specific first.
const LABEL_MAP = {
  policyRef:          ['reference', 'policy reference', 'policy ref', 'application reference', 'ref no', 'ref #', 'policy number', 'application number'],
  memberName:         ['member name', 'full name', 'name', 'member', 'employee name', 'applicant name', 'applicant'],
  surname:            ['surname', 'last name', 'family name'],
  firstName:          ['first name', 'given name', 'forename', 'name(s)'],
  idNumber:           ['id number', 'id no', 'identity number', 'id', 'id#', 'sa id', 'south african id'],
  payrollNumber:      ['payroll number', 'payroll no', 'employee number', 'employee no', 'staff number', 'payroll #'],
  employer:           ['employer', 'company', 'employer name', 'organisation', 'organization', 'employer/fund'],
  consultant:         ['consultant', 'agent', 'broker', 'advisor', 'financial advisor', 'sales consultant'],
  product:            ['product', 'plan', 'policy type', 'cover type', 'cover', 'product name', 'benefit', 'scheme'],
  membershipType:     ['membership type', 'membership category', 'category', 'tier', 'cover level', 'member type'],
  premium:            ['premium', 'monthly premium', 'monthly contribution', 'contribution', 'deduction amount', 'monthly deduction', 'premium/mo', 'premium amount'],
  effectiveDate:      ['deduction start', 'deduction start date', 'effective date', 'start date', 'commencement date', 'commencement', 'inception date'],
  beneficiaryName:    ['beneficiary', 'beneficiary name', 'nominated beneficiary', 'main beneficiary'],
  beneficiaryRelationship: ['beneficiary relationship', 'relationship', 'relation', 'beneficiary relation'],
  beneficiaryContact: ['beneficiary contact', 'beneficiary mobile', 'beneficiary phone', 'beneficiary number', 'beneficiary contact number'],
  mobile:             ['mobile', 'cell', 'cell number', 'mobile number', 'contact number', 'phone', 'telephone'],
  emailAddress:       ['email', 'e-mail', 'email address'],
  dateOfBirth:        ['date of birth', 'dob', 'birth date', 'birth'],
  billingFlag:        ['billing required', 'billing', 'send to billing', 'billing instruction'],
  actionRequired:     ['action required', 'action', 'instruction', 'please', 'required action'],
}

// ── Case type detection signals ───────────────────────────────────────────────
const CASE_TYPE_SIGNALS = [
  {
    id: 'ct_new_employee', name: 'New Employee',
    signals: [
      { terms: ['new policy activation','new application','policy activation','enrolment','new employee','new member application','amcu application','application record','new member'], weight: 12 },
      { terms: ['deduction start','effective date','commencement'], weight: 6 },
      { terms: ['premium','monthly contribution'], weight: 3 },
    ],
  },
  {
    id: 'ct_amcu_funeral', name: 'AMCU Funeral Claim',
    signals: [
      { terms: ['funeral claim','funeral benefit','death claim','deceased member','amcu funeral'], weight: 12 },
      { terms: ['death certificate','burial order','date of death','deceased'], weight: 8 },
    ],
  },
  {
    id: 'ct_extended_funeral', name: 'Extended Funeral Claim',
    signals: [
      { terms: ['extended funeral','extended cover','family member claim','dependent claim','extended benefit'], weight: 12 },
    ],
  },
  {
    id: 'ct_beneficiary', name: 'Beneficiary Nomination Form',
    signals: [
      { terms: ['beneficiary update','nomination form','nominee','change of beneficiary','beneficiary nomination'], weight: 12 },
    ],
  },
  {
    id: 'ct_benefit_statement', name: 'Benefit Statement Request',
    signals: [
      { terms: ['benefit statement','statement request','membership statement','policy statement','certificate of membership'], weight: 12 },
    ],
  },
  {
    id: 'ct_exit_employee', name: 'Exit Employee',
    signals: [
      { terms: ['resignation','termination','retrenchment','section 189','end of employment','separation'], weight: 12 },
      { terms: ['last day','exit date','termination date'], weight: 6 },
    ],
  },
  {
    id: 'ct_general_query', name: 'General Query',
    signals: [{ terms: ['query','question','request','please advise'], weight: 2 }],
  },
]

// ── Billing detection ─────────────────────────────────────────────────────────
const BILLING_SIGNALS = [
  'billing required', 'send to billing', 'billing: yes', 'billing:yes',
  'billing required: yes', 'process.*billing', 'billing system',
  'billing update', 'premium.*change', 'new.*premium', 'reinstatement',
]

// ─────────────────────────────────────────────────────────────────────────────
// EXTRACTION ENGINE — main function
// Returns extracted fields with source and confidence metadata
// ─────────────────────────────────────────────────────────────────────────────
function parseEmailText(rawText, fileName) {
  const raw   = rawText || ''
  const lower = raw.toLowerCase()
  const now   = new Date().toISOString()

  // ── Normalise text ────────────────────────────────────────────────────────
  // PDFs often have \r\n or multiple spaces. Normalise to single \n.
  const text  = raw.replace(/\r\n/g, '\n').replace(/\r/g, '\n').replace(/[ \t]{2,}/g, ' ').trim()
  const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0)

  // ── Build a label→value lookup from consecutive lines ────────────────────
  // Strategy: for each line, check if it matches a known label. If so, the
  // NEXT non-empty line is the value (unless it's also a label).
  const allLabels = Object.values(LABEL_MAP).flat().map(l => l.toLowerCase())

  function isLabel(line) {
    const l = line.toLowerCase().replace(/:$/, '').trim()
    return allLabels.some(lbl => l === lbl || l === lbl + ':' || l.startsWith(lbl + ':') || l.startsWith(lbl + ' '))
  }

  // Build a line-number → {key, rawLabel} map
  const labelLines = {}
  for (let i = 0; i < lines.length; i++) {
    const lineLower = lines[i].toLowerCase().replace(/:$/, '').trim()
    for (const [key, variants] of Object.entries(LABEL_MAP)) {
      for (const variant of variants) {
        if (lineLower === variant || lineLower === variant + ':' ||
            lineLower.startsWith(variant + ':') || lineLower.startsWith(variant + ' ')) {
          if (!labelLines[i]) labelLines[i] = { key, rawLabel: lines[i] }
        }
      }
    }
  }

  // ── Extract values using three strategies ─────────────────────────────────
  const extracted = {}   // key → { value, source, confidence, rawLine }
  const labelIndices = Object.keys(labelLines).map(Number).sort((a,b)=>a-b)

  // Strategy 1: LABEL\nVALUE (consecutive lines, Funeral Portal PDF format)
  for (let idx = 0; idx < labelIndices.length; idx++) {
    const lineNo = labelIndices[idx]
    const { key } = labelLines[lineNo]
    if (extracted[key]) continue  // already found by higher-priority strategy

    // Find next non-empty line that isn't itself a label
    for (let j = lineNo + 1; j < Math.min(lineNo + 4, lines.length); j++) {
      const candidate = lines[j].trim()
      if (!candidate) continue
      const candidateLower = candidate.toLowerCase()
      // Skip if this line IS a label
      if (Object.keys(labelLines).includes(String(j))) break
      // Skip if it looks like a section header (all caps > 4 chars)
      if (candidate === candidate.toUpperCase() && candidate.length > 4 && !/\d/.test(candidate)) break
      // Accept it
      extracted[key] = {
        value:      candidate,
        source:     `Line ${lineNo+1}→${j+1}: "${lines[lineNo]}" → "${candidate}"`,
        confidence: 90,
        strategy:   'label_newline',
      }
      break
    }
  }

  // Strategy 2: LABEL: VALUE on the same line (email / some PDFs)
  for (const [key, variants] of Object.entries(LABEL_MAP)) {
    if (extracted[key]) continue
    for (const variant of variants) {
      // "Label: value" or "Label : value"
      const re = new RegExp(
        variant.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') +
        '\\s*[:\\-]\\s*(.+?)(?:\\n|$)',
        'i'
      )
      const m = text.match(re)
      if (m && m[1]) {
        const val = m[1].trim()
        if (val.length >= 1 && val.length <= 120) {
          extracted[key] = {
            value:      val,
            source:     `Inline match: "${variant}: ${val}"`,
            confidence: 85,
            strategy:   'label_colon',
          }
          break
        }
      }
    }
  }

  // Strategy 3: INLINE patterns (ID numbers, phone numbers, emails, amounts)
  const inlinePatterns = [
    { key: 'idNumber',      re: /\b(\d{13})\b/,                                                  source: '13-digit ID number',        confidence: 95 },
    { key: 'mobile',        re: /\b(0[67]\d[\s\-]?\d{3}[\s\-]?\d{4})\b/,                         source: 'SA mobile number pattern',  confidence: 88 },
    { key: 'emailAddress',  re: /\b([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})\b/,       source: 'Email address pattern',     confidence: 92 },
    { key: 'policyRef',     re: /\b(AMCU[\-\/]\d{8}[\-\/]\d{4,8})\b/i,                            source: 'AMCU reference pattern',    confidence: 95 },
    { key: 'policyRef',     re: /\b([A-Z]{2,6}[\-\/]\d{6,10}[\-\/]\d{3,8})\b/,                   source: 'Portal reference pattern',  confidence: 80 },
    { key: 'premium',       re: /R\s*(\d{2,6}(?:\.\d{2})?)\s*(?:\/mo|pm|per month|monthly)/i,    source: 'Rand premium /mo pattern',  confidence: 90 },
    { key: 'premium',       re: /R\s*(\d{2,6}(?:\.\d{2})?)/,                                     source: 'Rand amount pattern',       confidence: 65 },
    { key: 'effectiveDate', re: /\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{4})\b/i, source: 'Month Year pattern',      confidence: 75 },
  ]
  for (const { key, re, source, confidence } of inlinePatterns) {
    if (extracted[key]) continue
    const m = text.match(re)
    if (m) {
      const val = (m[2] ? m[1] + ' ' + m[2] : m[1]).trim()
      extracted[key] = { value: val, source, confidence, strategy: 'inline' }
    }
  }

  // ── Post-process: clean up values ─────────────────────────────────────────
  for (const key of Object.keys(extracted)) {
    let v = extracted[key].value
    // Strip trailing punctuation
    v = v.replace(/[,;:]+$/, '').trim()
    // Remove repeated whitespace
    v = v.replace(/\s+/g, ' ')
    // Billing flag: normalise to Yes/No
    if (key === 'billingFlag') v = /yes|true|required|1/i.test(v) ? 'Yes' : 'No'
    // Premium: ensure R prefix
    if (key === 'premium' && !/^R/i.test(v)) v = 'R' + v
    extracted[key].value = v
  }

  // ── Synthesise memberName from first+surname if needed ────────────────────
  if (!extracted.memberName && (extracted.firstName || extracted.surname)) {
    const combined = [extracted.firstName?.value, extracted.surname?.value].filter(Boolean).join(' ')
    if (combined) extracted.memberName = { value: combined, source: 'Combined from first name + surname', confidence: 80, strategy: 'synthesised' }
  }

  // ── Detect case type ──────────────────────────────────────────────────────
  let scores = {}
  for (const ct of CASE_TYPE_SIGNALS) {
    scores[ct.id] = 0
    for (const group of ct.signals) {
      for (const term of group.terms) {
        if (lower.includes(term.toLowerCase())) {
          scores[ct.id] += group.weight; break
        }
      }
    }
  }
  // Bonus: if we found a policy ref with AMCU prefix, boost new employee score
  if (extracted.policyRef?.value?.toUpperCase().startsWith('AMCU')) scores['ct_new_employee'] = (scores['ct_new_employee'] || 0) + 8
  // Bonus: if beneficiaryName found, boost new employee (app forms have beneficiaries)
  if (extracted.beneficiaryName) scores['ct_new_employee'] = (scores['ct_new_employee'] || 0) + 4

  const sortedTypes = Object.entries(scores).sort((a,b)=>b[1]-a[1]).filter(([,s])=>s>0)
  const detectedCaseTypeId  = sortedTypes[0]?.[0] || 'ct_new_employee'
  const detectionConfidence = sortedTypes[0]?.[1] || 0

  // ── Billing detection ─────────────────────────────────────────────────────
  let billingRequired = BILLING_SIGNALS.some(sig => new RegExp(sig, 'i').test(lower))
  if (extracted.billingFlag?.value === 'Yes') billingRequired = true

  // ── Email subject / sender ────────────────────────────────────────────────
  const subjectMatch = text.match(/^subject[:\s]+(.+)$/im) || text.match(/^re[:\s]+(.+)$/im)
  const emailSubject = subjectMatch?.[1]?.trim() || lines[0]?.slice(0, 80) || fileName?.replace(/\.(eml|msg|pdf)$/i,'') || 'Email Import'
  const fromMatch    = text.match(/^from[:\s]+(.+)$/im)
  const emailFrom    = fromMatch?.[1]?.trim() || ''

  // ── Build clean extracted map (value strings only) for the form ───────────
  const extractedValues = {}
  for (const [key, meta] of Object.entries(extracted)) {
    extractedValues[key] = meta.value || ''
  }

  // ── Build debug metadata (includes source + confidence per field) ─────────
  const debugMeta = {}
  for (const [key, meta] of Object.entries(extracted)) {
    debugMeta[key] = { ...meta }
  }
  // Add not-found entries for all expected fields
  for (const key of Object.keys(LABEL_MAP)) {
    if (!debugMeta[key]) {
      debugMeta[key] = { value: '', source: 'Not found', confidence: 0, strategy: 'none' }
    }
  }

  return {
    emailSubject,
    emailFrom,
    detectedCaseTypeId,
    detectionConfidence,
    alternativeTypes: sortedTypes.slice(1, 4).map(([id]) => id),
    billingRequired,
    extracted:   extractedValues,
    debugMeta,
    rawText:     text,
    rawLines:    lines,
    processedAt: now,
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN PAGE COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
export default function EmailIntake({ caseTypes, categories, employers, users, currentUser, onCaseCreated }) {
  const [phase, setPhase]               = useState('upload')
  const [uploadedFile, setUploadedFile] = useState(null)
  const [parseResult, setParseResult]   = useState(null)
  const [dragging, setDragging]         = useState(false)
  const [progress, setProgress]         = useState(0)
  const [createdCase, setCreatedCase]   = useState(null)
  const fileInputRef = useRef()

  function readFile(file) {
    if (!file) return
    const ext = '.' + file.name.split('.').pop().toLowerCase()
    if (!['.eml','.msg','.pdf','.txt'].includes(ext)) {
      alert('Please upload an .eml, .msg, .pdf or .txt file.'); return
    }
    setUploadedFile(file); setPhase('processing')
    const reader = new FileReader()
    reader.onload = e => startProcessing(e.target.result, file.name)
    reader.onerror = () => { alert('Could not read file.'); setPhase('upload') }
    reader.readAsText(file)
  }

  function startProcessing(rawText, fileName) {
    let i = 0
    const steps = [20, 40, 60, 80, 100]
    const iv = setInterval(() => {
      if (i < steps.length) { setProgress(steps[i]); i++ }
      else {
        clearInterval(iv)
        setParseResult(parseEmailText(rawText, fileName))
        setPhase('review')
      }
    }, 280)
  }

  const onDrop = useCallback(e => {
    e.preventDefault(); setDragging(false)
    const f = e.dataTransfer.files[0]; if (f) readFile(f)
  }, [])

  const reset = () => { setPhase('upload'); setUploadedFile(null); setParseResult(null); setProgress(0) }

  if (phase === 'upload')     return <UploadPhase dragging={dragging} setDragging={setDragging} onDrop={onDrop} fileInputRef={fileInputRef} onPickFile={readFile}/>
  if (phase === 'processing') return <ProcessingPhase progress={progress} fileName={uploadedFile?.name}/>
  if (phase === 'review')     return (
    <ReviewPhase parseResult={parseResult} uploadedFile={uploadedFile}
      caseTypes={caseTypes} categories={categories} employers={employers}
      users={users} currentUser={currentUser}
      onBack={reset}
      onCreated={c => { setCreatedCase(c); setPhase('done'); onCaseCreated(c) }}/>
  )
  if (phase === 'done') return <DonePhase c={createdCase} onNew={() => { reset(); setCreatedCase(null) }}/>
}

// ─────────────────────────────────────────────────────────────────────────────
// PHASE 1 — UPLOAD
// ─────────────────────────────────────────────────────────────────────────────
function UploadPhase({ dragging, setDragging, onDrop, fileInputRef, onPickFile }) {
  return (
    <div style={{ maxWidth:680, margin:'0 auto', animation:'fadeIn .3s ease' }}>
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:24 }}>
        <div style={{ width:40, height:40, borderRadius:10, background:T.orangeL, display:'flex', alignItems:'center', justifyContent:'center' }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill={T.orange}><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
        </div>
        <div>
          <h1 style={{ fontSize:20, fontWeight:800, color:T.text, margin:0 }}>Create Case from Email</h1>
          <p style={{ margin:0, fontSize:12, color:T.gray }}>Upload a Funeral Portal PDF or email file — information will be extracted automatically.</p>
        </div>
      </div>

      <div onDrop={onDrop} onDragOver={e=>{e.preventDefault();setDragging(true)}} onDragLeave={e=>{e.preventDefault();setDragging(false)}}
        onClick={()=>fileInputRef.current.click()}
        style={{ border:`2px dashed ${dragging?T.orange:'#d1d5db'}`, borderRadius:14, padding:'52px 24px', textAlign:'center', cursor:'pointer', background:dragging?T.orangeL:'#fafafa', transition:'all .18s', marginBottom:20 }}>
        <input ref={fileInputRef} type="file" accept=".eml,.msg,.pdf,.txt" onChange={e=>{if(e.target.files[0])onPickFile(e.target.files[0]);e.target.value=''}} style={{display:'none'}}/>
        <div style={{ fontSize:52, marginBottom:14, lineHeight:1 }}>{dragging?'📂':'📧'}</div>
        <div style={{ fontSize:16, fontWeight:700, color:dragging?T.orange:T.text, marginBottom:6 }}>{dragging?'Release to process':'Drop email or PDF here'}</div>
        <div style={{ fontSize:13, color:T.gray, marginBottom:18 }}>or click to browse</div>
        <div style={{ display:'flex', gap:8, justifyContent:'center', flexWrap:'wrap' }}>
          {[{ext:'.EML',desc:'Email file',c:'#1e5fd9'},{ext:'.MSG',desc:'Outlook',c:'#7c3aed'},{ext:'.PDF',desc:'PDF copy',c:'#dc2626'}].map(f=>(
            <div key={f.ext} style={{ display:'flex', alignItems:'center', gap:6, padding:'6px 12px', background:'#fff', border:`1px solid ${T.border}`, borderRadius:8 }}>
              <span style={{ fontSize:11, fontWeight:800, color:f.c }}>{f.ext}</span>
              <span style={{ fontSize:11, color:T.gray }}>{f.desc}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ background:'#fff', border:`1px solid ${T.border}`, borderRadius:12, padding:'16px 18px' }}>
        <div style={{ fontSize:12, fontWeight:700, color:T.text, marginBottom:12 }}>How it works</div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:10 }}>
          {[['📧','Upload','Drop Funeral Portal PDF or email'],['🔍','Extract','Labels & values parsed automatically'],['✏️','Review','Confirm or edit any field'],['✅','Create','Case allocated to your team']].map(([ic,t,d])=>(
            <div key={t} style={{ textAlign:'center', padding:'8px 4px' }}>
              <div style={{ fontSize:24, marginBottom:6 }}>{ic}</div>
              <div style={{ fontSize:12, fontWeight:700, color:T.text, marginBottom:2 }}>{t}</div>
              <div style={{ fontSize:11, color:T.gray, lineHeight:1.4 }}>{d}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// PHASE 2 — PROCESSING
// ─────────────────────────────────────────────────────────────────────────────
function ProcessingPhase({ progress, fileName }) {
  const steps = [{pct:0,l:'Reading document'},{pct:20,l:'Parsing labels and values'},{pct:40,l:'Extracting member data'},{pct:60,l:'Detecting case type'},{pct:80,l:'Checking billing flags'}]
  return (
    <div style={{ maxWidth:480, margin:'80px auto', textAlign:'center', animation:'fadeIn .3s ease' }}>
      <div style={{ fontSize:52, marginBottom:16, lineHeight:1, display:'inline-block', animation:'spin 1.5s linear infinite' }}>⚙️</div>
      <div style={{ fontSize:18, fontWeight:700, color:T.text, marginBottom:4 }}>Processing Document</div>
      <div style={{ fontSize:12, color:T.gray, marginBottom:20 }}>{fileName}</div>
      <div style={{ height:8, background:'#f3f4f6', borderRadius:4, maxWidth:340, margin:'0 auto 8px', overflow:'hidden' }}>
        <div style={{ height:'100%', width:`${progress}%`, background:`linear-gradient(90deg,${T.orange},#c95500)`, borderRadius:4, transition:'width .28s ease' }}/>
      </div>
      <div style={{ fontSize:11, color:T.gray, marginBottom:24 }}>{progress}%</div>
      <div style={{ display:'flex', flexDirection:'column', gap:6, maxWidth:300, margin:'0 auto' }}>
        {steps.map(s=>(
          <div key={s.l} style={{ display:'flex', alignItems:'center', gap:10, padding:'6px 12px', background:'#f9fafb', borderRadius:8 }}>
            <span style={{ fontSize:13 }}>{progress>s.pct?'✅':progress===s.pct?'⏳':'○'}</span>
            <span style={{ fontSize:12, color:progress>=s.pct?T.text:T.gray, fontWeight:progress>=s.pct?600:400 }}>{s.l}</span>
          </div>
        ))}
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// PHASE 3 — REVIEW
// ─────────────────────────────────────────────────────────────────────────────

// All editable fields shown in the review form
const REVIEW_FIELDS = [
  { key:'policyRef',              label:'Policy / Reference Number' },
  { key:'memberName',             label:'Member Name' },
  { key:'surname',                label:'Surname' },
  { key:'firstName',              label:'First Name' },
  { key:'idNumber',               label:'ID Number' },
  { key:'payrollNumber',          label:'Payroll Number' },
  { key:'employer',               label:'Employer' },
  { key:'consultant',             label:'Consultant' },
  { key:'product',                label:'Product / Cover' },
  { key:'membershipType',         label:'Membership Type' },
  { key:'premium',                label:'Premium' },
  { key:'effectiveDate',          label:'Deduction Start Date' },
  { key:'beneficiaryName',        label:'Beneficiary Name' },
  { key:'beneficiaryRelationship',label:'Beneficiary Relationship' },
  { key:'beneficiaryContact',     label:'Beneficiary Contact' },
  { key:'mobile',                 label:'Mobile Number' },
  { key:'emailAddress',           label:'Email Address' },
  { key:'dateOfBirth',            label:'Date of Birth' },
  { key:'actionRequired',         label:'Action Required' },
]

function ReviewPhase({ parseResult, uploadedFile, caseTypes, categories, employers, users, currentUser, onBack, onCreated }) {
  const r = parseResult
  const today = new Date().toISOString().split('T')[0]

  const [fields, setFields]               = useState({ ...r.extracted })
  const [selectedCaseTypeId, setSelectedCTId] = useState(r.detectedCaseTypeId)
  const [selectedEmployerId, setSelectedEmpId] = useState(
    employers.find(e => r.extracted.employer && e.name.toLowerCase().includes((r.extracted.employer||'').toLowerCase().slice(0,5)))?.id || ''
  )
  const [priority, setPriority]           = useState('Medium')
  const [billingRequired, setBilling]     = useState(r.billingRequired)
  const [description, setDescription]    = useState([r.emailSubject, r.extracted.actionRequired].filter(Boolean).join('\n\n') || `Imported from: ${uploadedFile?.name}`)
  const [activeTab, setActiveTab]         = useState('extracted')
  const [submitting, setSubmitting]       = useState(false)

  const setF = (k, v) => setFields(f => ({ ...f, [k]: v }))
  const selectedCT   = caseTypes.find(ct => ct.id === selectedCaseTypeId)
  const visibleCTs   = caseTypes.filter(ct => !ct.isInternal && ct.active)
  const extractedCt  = Object.values(r.extracted).filter(v => v?.trim()).length
  const totalFields  = REVIEW_FIELDS.length
  const confColor    = r.detectionConfidence >= 12 ? T.green : r.detectionConfidence >= 6 ? T.amber : T.red

  function handleCreate() {
    if (!selectedCaseTypeId || !selectedEmployerId) {
      alert('Please select a Case Type and Employer.'); return
    }
    setSubmitting(true)
    setTimeout(() => {
      const ct           = caseTypes.find(x => x.id === selectedCaseTypeId)
      const assignedTo   = allocateCase(ct, users, { general:{ members:['u2','u3','u6'] }, billing:{ members:['u5','u7'] } }, {})
      const assignedUser = users.find(u => u.id === assignedTo)
      const caseRef      = genRef('AEB')
      const slaDate      = ct ? calcSlaDate(ct) : new Date(Date.now()+5*86400000).toISOString().split('T')[0]
      const now          = new Date().toISOString()
      const memberName   = fields.memberName || [fields.firstName, fields.surname].filter(Boolean).join(' ') || null

      const documents = [{ name: uploadedFile?.name||'email_import.pdf', size:`${((uploadedFile?.size||0)/1024).toFixed(1)} KB`, type: uploadedFile?.type||'application/pdf', uploadedBy: currentUser.id, date: today, source:'email_import' }]

      const audit = [
        { time:now,                                user:currentUser.id, action:`Email uploaded: ${uploadedFile?.name}`,                               type:'upload'  },
        { time:r.processedAt,                      user:'system',       action:`Document processed — ${extractedCt} of ${totalFields} fields extracted`, type:'process' },
        { time:new Date(Date.now()+100).toISOString(), user:'system',   action:`Case type detected: ${ct?.name} (score: ${r.detectionConfidence})`,  type:'process' },
        { time:new Date(Date.now()+200).toISOString(), user:currentUser.id, action:`Case ${caseRef} created from email import`,                       type:'create'  },
        ...(assignedTo ? [{ time:new Date(Date.now()+300).toISOString(), user:'system', action:`Auto-assigned to ${assignedUser?.name||assignedTo} (Round Robin)`, type:'assign' }] : []),
        ...(billingRequired ? [{ time:new Date(Date.now()+400).toISOString(), user:'system', action:'Billing Required flag set — billing task will be created', type:'billing' }] : []),
      ]

      onCreated({
        id:'c'+Date.now(), ref:caseRef, workspace:'employer',
        caseTypeId:selectedCaseTypeId, employerId:selectedEmployerId,
        status:'Submitted', priority, assignedTo,
        createdBy:currentUser.id, memberName,
        memberId:fields.idNumber||null, source:'email_import', sourceFile:uploadedFile?.name,
        currentStage:0, stageHistory:[], created:today, slaDate,
        description:description.trim(), billingRequired, billingTaskId:null,
        notes:[], documents,
        emailData:{ subject:r.emailSubject, from:r.emailFrom, fileName:uploadedFile?.name, extractedFields:fields, processedAt:r.processedAt },
        audit, escalated:false,
        ownerHistory: assignedTo ? [{ user:assignedTo, from:today }] : [],
      })
    }, 500)
  }

  const tabs = [
    { id:'extracted', label:`📋 Extracted Data (${extractedCt}/${totalFields})` },
    { id:'case',      label:'⚙️ Case Settings' },
    { id:'debug',     label:'🔬 Debug Panel' },
    { id:'raw',       label:'📄 Raw Text' },
  ]

  return (
    <div style={{ maxWidth:980, margin:'0 auto', animation:'fadeIn .3s ease' }}>

      {/* Header */}
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:20, gap:12, flexWrap:'wrap' }}>
        <div>
          <button onClick={onBack} style={{ fontSize:12, color:T.orange, background:'none', border:'none', cursor:'pointer', fontWeight:600, padding:0, fontFamily:'inherit', marginBottom:6 }}>← Upload different file</button>
          <h1 style={{ fontSize:20, fontWeight:800, color:T.text, margin:'0 0 3px' }}>Intake Review</h1>
          <p style={{ margin:0, fontSize:12, color:T.gray }}>Review extracted information, correct any errors, then create the case.</p>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 14px', background:'#fff', border:`1px solid ${T.border}`, borderRadius:10 }}>
          <span style={{ fontSize:20 }}>📧</span>
          <div>
            <div style={{ fontSize:12, fontWeight:600, color:T.text }}>{uploadedFile?.name}</div>
            <div style={{ fontSize:10, color:T.gray }}>
              <span style={{ color:confColor, fontWeight:700 }}>{extractedCt} fields extracted</span>
              {' '} · Confidence: <span style={{ color:confColor, fontWeight:700 }}>{r.detectionConfidence >= 12 ? 'High' : r.detectionConfidence >= 6 ? 'Medium' : 'Low'}</span>
            </div>
          </div>
        </div>
      </div>

      {billingRequired && (
        <div style={{ background:'#f5f3ff', border:'1px solid #c4b5fd', borderRadius:10, padding:'11px 16px', marginBottom:16, display:'flex', alignItems:'center', gap:12 }}>
          <span style={{ fontSize:18 }}>💳</span>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:13, fontWeight:700, color:T.purple }}>Billing Required detected</div>
            <div style={{ fontSize:12, color:'#6d28d9' }}>This document contains billing instructions. Use "Approve & Send to Billing" below.</div>
          </div>
          <button onClick={()=>setBilling(false)} style={{ background:'none', border:'none', cursor:'pointer', color:T.gray, fontSize:11 }}>Dismiss</button>
        </div>
      )}

      <div style={{ display:'grid', gridTemplateColumns:'1fr 288px', gap:18, alignItems:'start' }}>

        {/* LEFT — tabs */}
        <div>
          {/* Tab bar */}
          <div style={{ display:'flex', background:'#fff', borderRadius:'12px 12px 0 0', borderBottom:`1px solid ${T.border}`, overflowX:'auto' }}>
            {tabs.map(tab => (
              <button key={tab.id} onClick={()=>setActiveTab(tab.id)}
                style={{ padding:'11px 16px', background:'none', border:'none', borderBottom:activeTab===tab.id?`2px solid ${T.orange}`:'2px solid transparent', color:activeTab===tab.id?T.orange:T.gray, fontWeight:activeTab===tab.id?700:400, fontSize:12, cursor:'pointer', fontFamily:'inherit', whiteSpace:'nowrap', marginBottom:-1 }}>
                {tab.label}
              </button>
            ))}
          </div>

          {/* ── Extracted Data tab ── */}
          {activeTab==='extracted' && (
            <div style={{ background:'#fff', border:`1px solid ${T.border}`, borderTop:'none', borderRadius:'0 0 12px 12px', padding:'18px 20px' }}>
              <div style={{ fontSize:12, color:T.gray, marginBottom:16, display:'flex', alignItems:'center', gap:8 }}>
                <div style={{ height:6, background:'#f3f4f6', borderRadius:3, flex:1 }}>
                  <div style={{ height:'100%', width:`${(extractedCt/totalFields)*100}%`, background:confColor, borderRadius:3, transition:'width .4s' }}/>
                </div>
                <span style={{ fontSize:11, fontWeight:700, color:confColor, whiteSpace:'nowrap' }}>{extractedCt}/{totalFields} fields</span>
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
                {REVIEW_FIELDS.map(({ key, label }) => {
                  const wasExtracted = !!(r.extracted[key] && r.extracted[key].trim())
                  const conf = r.debugMeta[key]?.confidence || 0
                  return (
                    <div key={key}>
                      <label style={{ fontSize:10, fontWeight:700, color:T.gray, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:4, display:'flex', alignItems:'center', gap:5 }}>
                        {label}
                        {wasExtracted
                          ? <span style={{ fontSize:9, color:T.green, fontWeight:700, background:'#f0fdf4', padding:'1px 5px', borderRadius:3 }}>AUTO {conf}%</span>
                          : <span style={{ fontSize:9, color:'#9ca3af', fontWeight:600, background:'#f3f4f6', padding:'1px 5px', borderRadius:3 }}>MANUAL</span>
                        }
                      </label>
                      <input value={fields[key]||''} onChange={e=>setF(key,e.target.value)}
                        placeholder={`Enter ${label.toLowerCase()}…`}
                        style={{ ...inputSt, fontSize:13, background:wasExtracted?'#f0fdf4':'#fff', borderColor:wasExtracted?'#bbf7d0':T.border }}/>
                    </div>
                  )
                })}
              </div>
              <div style={{ marginTop:16 }}>
                <label style={{ fontSize:10, fontWeight:700, color:T.gray, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:4, display:'block' }}>Case Description *</label>
                <textarea value={description} onChange={e=>setDescription(e.target.value)} rows={3} style={{ ...inputSt, resize:'vertical', fontSize:13 }}/>
              </div>
            </div>
          )}

          {/* ── Case Settings tab ── */}
          {activeTab==='case' && (
            <div style={{ background:'#fff', border:`1px solid ${T.border}`, borderTop:'none', borderRadius:'0 0 12px 12px', padding:'18px 20px' }}>

              {/* Case type picker */}
              <div style={{ marginBottom:20 }}>
                <div style={{ fontSize:12, fontWeight:700, color:T.text, marginBottom:8, display:'flex', alignItems:'center', gap:8 }}>
                  Case Type
                  <span style={{ fontSize:10, fontWeight:700, color:confColor, background:confColor+'18', padding:'2px 8px', borderRadius:20 }}>
                    {r.detectionConfidence>=12?'✓ High confidence':r.detectionConfidence>=6?'~ Medium':' ? Low — please verify'}
                  </span>
                </div>
                <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
                  {visibleCTs.map(ct => {
                    const isDetected = ct.id === r.detectedCaseTypeId
                    const isAlt      = r.alternativeTypes.includes(ct.id)
                    const isSel      = ct.id === selectedCaseTypeId
                    return (
                      <button key={ct.id} onClick={()=>setSelectedCTId(ct.id)}
                        style={{ padding:'10px 14px', borderRadius:9, border:`2px solid ${isSel?T.orange:isDetected?T.green+'60':T.border}`, background:isSel?T.orangeL:isDetected?'#f0fdf4':'#fff', textAlign:'left', cursor:'pointer', display:'flex', justifyContent:'space-between', alignItems:'center', fontFamily:'inherit' }}>
                        <span>
                          <span style={{ fontSize:13, fontWeight:isSel?700:500, color:T.text }}>{ct.name}</span>
                          <span style={{ fontSize:11, color:T.gray, marginLeft:8 }}>{ct.slaLabel}</span>
                        </span>
                        <span style={{ display:'flex', gap:4 }}>
                          {isDetected && <span style={{ fontSize:9, fontWeight:700, color:T.green, background:'#f0fdf4', padding:'2px 6px', borderRadius:3 }}>DETECTED</span>}
                          {!isDetected && isAlt && <span style={{ fontSize:9, fontWeight:700, color:T.amber, background:'#fffbeb', padding:'2px 6px', borderRadius:3 }}>ALT</span>}
                          {isSel && <span style={{ fontSize:9, fontWeight:700, color:T.orange, background:T.orangeL, padding:'2px 6px', borderRadius:3 }}>SELECTED</span>}
                        </span>
                      </button>
                    )
                  })}
                </div>
              </div>

              {/* Employer */}
              <div style={{ marginBottom:16 }}>
                <label style={{ fontSize:10, fontWeight:700, color:T.gray, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:6, display:'block' }}>Employer *</label>
                {r.extracted.employer && <div style={{ fontSize:11, color:T.gray, marginBottom:6 }}>From document: <strong style={{ color:T.text }}>{r.extracted.employer}</strong></div>}
                <select value={selectedEmployerId} onChange={e=>setSelectedEmpId(e.target.value)} style={selectSt}>
                  <option value="">Select employer…</option>
                  {employers.map(e=><option key={e.id} value={e.id}>{e.name} ({e.number})</option>)}
                </select>
              </div>

              {/* Priority */}
              <div style={{ marginBottom:16 }}>
                <label style={{ fontSize:10, fontWeight:700, color:T.gray, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:6, display:'block' }}>Priority</label>
                <div style={{ display:'flex', gap:7 }}>
                  {['Low','Medium','High','Critical'].map(p=>(
                    <button key={p} onClick={()=>setPriority(p)} style={{ flex:1, padding:'8px 4px', borderRadius:7, border:`1.5px solid ${priority===p?T.orange:T.border}`, background:priority===p?T.orange:'#fff', color:priority===p?'#fff':'#374151', fontSize:12, fontWeight:600, cursor:'pointer', fontFamily:'inherit' }}>{p}</button>
                  ))}
                </div>
              </div>

              {/* Billing toggle */}
              <div style={{ padding:'12px 14px', background:billingRequired?'#f5f3ff':'#f9fafb', border:`1px solid ${billingRequired?'#c4b5fd':T.border}`, borderRadius:9 }}>
                <label style={{ display:'flex', alignItems:'center', gap:10, cursor:'pointer' }}>
                  <div onClick={()=>setBilling(b=>!b)} style={{ width:38, height:22, borderRadius:11, background:billingRequired?T.purple:'#d1d5db', position:'relative', transition:'background .2s', flexShrink:0 }}>
                    <div style={{ width:18, height:18, borderRadius:'50%', background:'#fff', position:'absolute', top:2, left:billingRequired?18:2, transition:'left .2s', boxShadow:'0 1px 3px rgba(0,0,0,0.2)' }}/>
                  </div>
                  <div>
                    <div style={{ fontSize:12, fontWeight:700, color:billingRequired?T.purple:T.text }}>Billing Required</div>
                    <div style={{ fontSize:11, color:T.gray }}>Creates a Billing Task assigned to billing queue after case creation</div>
                  </div>
                </label>
              </div>
            </div>
          )}

          {/* ── Debug Panel tab ── */}
          {activeTab==='debug' && (
            <div style={{ background:'#fff', border:`1px solid ${T.border}`, borderTop:'none', borderRadius:'0 0 12px 12px', overflow:'hidden' }}>
              <div style={{ padding:'12px 16px', background:'#f9fafb', borderBottom:`1px solid ${T.border}`, display:'flex', alignItems:'center', gap:10 }}>
                <span style={{ fontSize:18 }}>🔬</span>
                <div>
                  <div style={{ fontSize:13, fontWeight:700, color:T.text }}>Extraction Debug Panel</div>
                  <div style={{ fontSize:11, color:T.gray }}>Shows every field, its extracted value, the source location, and confidence score. Use this to validate and tune the extraction engine.</div>
                </div>
              </div>
              <div style={{ overflowX:'auto' }}>
                <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
                  <thead>
                    <tr style={{ background:'#f3f4f6' }}>
                      {['Field','Extracted Value','Source / Location','Strategy','Confidence'].map(h=>(
                        <th key={h} style={{ padding:'9px 12px', textAlign:'left', fontSize:10, fontWeight:700, color:T.gray, textTransform:'uppercase', letterSpacing:'0.4px', whiteSpace:'nowrap', borderBottom:`1px solid ${T.border}` }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {REVIEW_FIELDS.map(({ key, label }) => {
                      const meta = r.debugMeta[key] || { value:'', source:'Not found', confidence:0, strategy:'none' }
                      const found = !!meta.value
                      const strategyColors = { label_newline:'#1e5fd9', label_colon:'#059669', inline:'#7c3aed', synthesised:'#d97706', none:'#9ca3af' }
                      const strategyLabels = { label_newline:'Label↵Value', label_colon:'Label: Value', inline:'Pattern match', synthesised:'Synthesised', none:'Not found' }
                      return (
                        <tr key={key} style={{ borderBottom:`1px solid #f9fafb`, background:found?'#fff':'#fff8f8' }}>
                          <td style={{ padding:'9px 12px', fontWeight:600, color:T.text, whiteSpace:'nowrap' }}>{label}</td>
                          <td style={{ padding:'9px 12px', maxWidth:180 }}>
                            {found
                              ? <span style={{ fontSize:12, color:T.text, fontWeight:600, fontFamily:key==='idNumber'?'monospace':'inherit' }}>{meta.value}</span>
                              : <span style={{ fontSize:11, color:'#d1d5db', fontStyle:'italic' }}>—</span>
                            }
                          </td>
                          <td style={{ padding:'9px 12px', maxWidth:240 }}>
                            <span style={{ fontSize:10, color:T.gray, lineHeight:1.4, display:'block' }}>{meta.source}</span>
                          </td>
                          <td style={{ padding:'9px 12px' }}>
                            <span style={{ fontSize:10, fontWeight:700, color:strategyColors[meta.strategy||'none'], background:strategyColors[meta.strategy||'none']+'18', padding:'2px 7px', borderRadius:4, whiteSpace:'nowrap' }}>
                              {strategyLabels[meta.strategy||'none']}
                            </span>
                          </td>
                          <td style={{ padding:'9px 12px' }}>
                            <div style={{ display:'flex', alignItems:'center', gap:7 }}>
                              <div style={{ width:52, height:5, background:'#f3f4f6', borderRadius:3, overflow:'hidden' }}>
                                <div style={{ height:'100%', width:`${meta.confidence}%`, background:meta.confidence>=80?T.green:meta.confidence>=50?T.amber:T.red, borderRadius:3 }}/>
                              </div>
                              <span style={{ fontSize:11, fontWeight:700, color:meta.confidence>=80?T.green:meta.confidence>=50?T.amber:meta.confidence>0?T.red:'#d1d5db' }}>{meta.confidence}%</span>
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
              {/* Parsed lines view for diagnostics */}
              <div style={{ padding:'14px 16px', borderTop:`1px solid ${T.border}`, background:'#f9fafb' }}>
                <div style={{ fontSize:11, fontWeight:700, color:T.text, marginBottom:8 }}>Parsed Lines ({r.rawLines?.length || 0} non-empty lines detected)</div>
                <div style={{ display:'flex', flexDirection:'column', gap:2, maxHeight:200, overflowY:'auto' }}>
                  {(r.rawLines||[]).slice(0,60).map((line,i)=>(
                    <div key={i} style={{ display:'flex', gap:10, fontSize:11, fontFamily:'monospace' }}>
                      <span style={{ color:'#9ca3af', minWidth:28, textAlign:'right' }}>{i+1}</span>
                      <span style={{ color:T.text }}>{line.slice(0,120)}</span>
                    </div>
                  ))}
                  {(r.rawLines||[]).length > 60 && <div style={{ fontSize:11, color:T.gray, padding:'4px 0' }}>… {r.rawLines.length - 60} more lines</div>}
                </div>
              </div>
            </div>
          )}

          {/* ── Raw Text tab ── */}
          {activeTab==='raw' && (
            <div style={{ background:'#1e1e2e', border:`1px solid #2d2d3f`, borderTop:'none', borderRadius:'0 0 12px 12px', padding:'16px 18px' }}>
              <div style={{ fontSize:11, color:'#6b7280', marginBottom:8, fontFamily:'monospace' }}>{uploadedFile?.name} · {uploadedFile ? (uploadedFile.size/1024).toFixed(1)+' KB' : ''}</div>
              <pre style={{ fontSize:11, color:'#a8b5cc', fontFamily:'monospace', lineHeight:1.6, whiteSpace:'pre-wrap', wordBreak:'break-word', maxHeight:420, overflowY:'auto', margin:0 }}>
                {r.rawText?.slice(0,5000)||'No readable text extracted.'}
                {r.rawText?.length>5000&&'\n\n[… truncated …]'}
              </pre>
            </div>
          )}
        </div>

        {/* RIGHT — summary + actions */}
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>

          {/* Detection summary */}
          <div style={{ background:'#fff', border:`1px solid ${T.border}`, borderRadius:12, padding:'15px 16px' }}>
            <div style={{ fontSize:12, fontWeight:700, color:T.text, marginBottom:12 }}>Extraction Summary</div>
            {[
              ['Subject',      r.emailSubject],
              ['Detected Type',caseTypes.find(ct=>ct.id===selectedCaseTypeId)?.name||'—'],
              ['Confidence',   r.detectionConfidence>=12?'High ✓':r.detectionConfidence>=6?'Medium ~':'Low ⚠'],
              ['Fields Found', `${extractedCt} / ${totalFields}`],
              ['Billing Flag', billingRequired?'Yes ⚡':'No'],
              ['SLA',          selectedCT?.slaLabel||'—'],
            ].map(([k,v])=>v&&(
              <div key={k} style={{ display:'flex', justifyContent:'space-between', gap:8, padding:'4px 0', borderBottom:'1px solid #f9fafb' }}>
                <span style={{ fontSize:11, color:T.gray }}>{k}</span>
                <span style={{ fontSize:11, fontWeight:600, color:k==='Detected Type'?T.orange:k==='Confidence'?confColor:T.text, textAlign:'right', maxWidth:140, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{v}</span>
              </div>
            ))}
          </div>

          {/* Key fields snapshot */}
          <div style={{ background:'#fff', border:`1px solid ${T.border}`, borderRadius:12, padding:'15px 16px' }}>
            <div style={{ fontSize:12, fontWeight:700, color:T.text, marginBottom:12 }}>Key Fields</div>
            {[
              ['Member',          fields.memberName||[fields.firstName,fields.surname].filter(Boolean).join(' ')],
              ['ID Number',       fields.idNumber],
              ['Employer',        fields.employer],
              ['Product',         fields.product],
              ['Premium',         fields.premium],
              ['Effective Date',  fields.effectiveDate],
              ['Beneficiary',     fields.beneficiaryName],
              ['Contact',         fields.beneficiaryContact||fields.mobile],
            ].filter(([,v])=>v).map(([k,v])=>(
              <div key={k} style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', padding:'5px 0', borderBottom:'1px solid #f3f4f6' }}>
                <span style={{ fontSize:11, color:T.gray, flexShrink:0 }}>{k}</span>
                <span style={{ fontSize:11, fontWeight:600, color:T.text, textAlign:'right', maxWidth:150, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{v}</span>
              </div>
            ))}
            {extractedCt===0&&<div style={{ fontSize:12, color:T.gray, textAlign:'center', padding:8 }}>No fields extracted. Enter details manually.</div>}
          </div>

          {/* Action buttons */}
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {billingRequired ? (
              <>
                <button onClick={handleCreate} disabled={submitting}
                  style={{ padding:'13px', background:T.purple, color:'#fff', border:'none', borderRadius:9, fontSize:13, fontWeight:700, cursor:submitting?'not-allowed':'pointer', opacity:submitting?.7:1, fontFamily:'inherit' }}>
                  {submitting?'⏳ Creating…':'✅ Approve & Send to Billing'}
                </button>
                <button onClick={handleCreate} disabled={submitting}
                  style={{ padding:'13px', background:T.navy, color:'#fff', border:'none', borderRadius:9, fontSize:13, fontWeight:700, cursor:submitting?'not-allowed':'pointer', opacity:submitting?.7:1, fontFamily:'inherit' }}>
                  Approve Only
                </button>
              </>
            ) : (
              <button onClick={handleCreate} disabled={submitting}
                style={{ padding:'13px', background:T.navy, color:'#fff', border:'none', borderRadius:9, fontSize:13, fontWeight:700, cursor:submitting?'not-allowed':'pointer', opacity:submitting?.7:1, fontFamily:'inherit', display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
                {submitting?'⏳ Creating case…':'✅ Create Case'}
              </button>
            )}
            <button onClick={onBack} disabled={submitting}
              style={{ padding:'9px', background:'none', border:`1px solid ${T.border}`, borderRadius:9, fontSize:12, color:T.gray, cursor:'pointer', fontFamily:'inherit' }}>
              ← Upload Different File
            </button>
          </div>

          {/* Allocation note */}
          <div style={{ background:'#f0f7ff', border:'1px solid #bfdbfe', borderRadius:10, padding:'12px 14px' }}>
            <div style={{ fontSize:11, fontWeight:700, color:T.blue, marginBottom:4 }}>Auto-Allocation</div>
            <div style={{ fontSize:11, color:'#374151', lineHeight:1.5 }}>Assigned via Round Robin to the <strong>General Administration Pool</strong>.</div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// PHASE 4 — DONE
// ─────────────────────────────────────────────────────────────────────────────
function DonePhase({ c, onNew }) {
  return (
    <div style={{ maxWidth:520, margin:'60px auto', textAlign:'center', animation:'fadeIn .4s ease' }}>
      <div style={{ fontSize:60, marginBottom:14, lineHeight:1 }}>🎉</div>
      <h2 style={{ fontSize:22, fontWeight:800, color:T.text, margin:'0 0 6px' }}>Case Created Successfully</h2>
      <div style={{ fontSize:13, color:T.gray, marginBottom:24 }}>The document has been processed and the case has been allocated to your team.</div>
      <div style={{ background:'#fff', border:`1px solid ${T.border}`, borderRadius:14, padding:'20px 22px', marginBottom:22, textAlign:'left' }}>
        <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:14, paddingBottom:12, borderBottom:`1px solid ${T.border}` }}>
          <div style={{ width:42, height:42, borderRadius:10, background:T.orangeL, display:'flex', alignItems:'center', justifyContent:'center', fontSize:20 }}>📋</div>
          <div>
            <div style={{ fontFamily:'monospace', fontSize:15, fontWeight:800, color:T.orange }}>{c?.ref}</div>
            <StatusBadge status="Submitted"/>
          </div>
        </div>
        {[['Source','📧 Email Import'],['Member',c?.memberName||'—'],['SLA Due',c?.slaDate],['Source File',c?.sourceFile]].map(([k,v])=>(
          <div key={k} style={{ display:'flex', justifyContent:'space-between', padding:'5px 0', borderBottom:'1px solid #f9fafb' }}>
            <span style={{ fontSize:12, color:T.gray }}>{k}</span>
            <span style={{ fontSize:12, fontWeight:600, color:T.text }}>{v||'—'}</span>
          </div>
        ))}
      </div>
      <div style={{ background:'#f0fdf4', border:'1px solid #bbf7d0', borderRadius:10, padding:'12px 16px', marginBottom:22, textAlign:'left' }}>
        <div style={{ fontSize:12, fontWeight:700, color:T.green, marginBottom:6 }}>✓ Timeline events recorded</div>
        {['Email uploaded and attached to case','Document processed and fields extracted','Case created with reference number','Auto-allocated to administrator (Round Robin)'].map(ev=>(
          <div key={ev} style={{ fontSize:11, color:'#374151', display:'flex', alignItems:'center', gap:6, marginBottom:3 }}>
            <span style={{ color:T.green }}>✓</span>{ev}
          </div>
        ))}
      </div>
      <button onClick={onNew} style={{ padding:'10px 22px', background:T.navy, color:'#fff', border:'none', borderRadius:8, fontSize:13, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>
        📧 Process Another Document
      </button>
    </div>
  )
}
